package domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
public class Product implements Serializable {

    int id;
    String name;
    String brad;
    String madeIn;
    float price;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrad() {
        return brad;
    }

    public void setBrad(String brad) {
        this.brad = brad;
    }

    public String getMadeIn() {
        return madeIn;
    }

    public void setMadeIn(String madeIn) {
        this.madeIn = madeIn;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Product(int id, String name, String brad, String madeIn, float price) {
        this.id = id;
        this.name = name;
        this.brad = brad;
        this.madeIn = madeIn;
        this.price = price;
    }
    public Product(String name, String brad, String madeIn, float price) {
        this.name = name;
        this.brad = brad;
        this.madeIn = madeIn;
        this.price = price;
    }
    public Product() {
        super();
    }




}
