package service;

import domain.Product;

import java.util.List;

public interface ProductInterface {

    Product findById(int id);
    Product findByName(String name);
    Product saveProduct(Product product);
    void updateProduct(Product product);
    void deleteProduct(int id);
    List<Product> findAllProduct();
    boolean isProductExist(Product product);

}
