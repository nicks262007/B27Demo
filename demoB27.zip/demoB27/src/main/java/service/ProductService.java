package service;

import domain.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
class ProductService implements ProductInterface{

    Map<Integer, Product> products = new HashMap<Integer, Product>();
    Map<String, Integer> idNameHM = new HashMap<String, Integer>();
    static int id =0;

    @Override
    public Product findById(int id) {
        return products.get(id);
    }

    @Override
    public Product findByName(String name) {
        Product productFound = null;
        if (idNameHM.get(name)!=null){
            productFound = products.get(idNameHM.get(name));
        }
        return productFound;
    }

    @Override
    public Product saveProduct(Product product) {
        product.setId(generateId());
        products.put(product.getId(), product);
        idNameHM.put(product.getName(),product.getId());
        return product;
    }

    @Override
    public void updateProduct(Product product) {
        synchronized (this){
            products.put(product.getId(), product);
            idNameHM.put(product.getName(),product.getId());
        }
    }

    @Override
    public void deleteProduct(int id) {
        synchronized (this){
            idNameHM.remove(products.get(id).getName());
            products.remove(id);
        }

    }

    @Override
    public List<Product> findAllProduct() {
        return new ArrayList<Product>(products.values());
    }

    @Override
    public boolean isProductExist(Product product) {
        return findByName(product.getName())!=null;
    }

    private int generateId(){
        return ++id;
    }
}
