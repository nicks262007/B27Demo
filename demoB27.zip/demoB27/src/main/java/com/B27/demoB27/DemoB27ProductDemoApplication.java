package com.B27.demoB27;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoB27ProductDemoApplication {

	public static void main(String[] args) {

		SpringApplication.run(DemoB27ProductDemoApplication.class, args);
		System.out.println("Server started at the port 7878!!!");
	}

}
