package controller;

import domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import service.ProductInterface;
import util.CustomManageErrors;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductController {

    @Autowired
    ProductInterface service;

    @GetMapping("/")
    public ResponseEntity<String> getMessage(){
        return new ResponseEntity<String>("Welcome to Restfull WS!!!", HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> createRecord(@Validated @RequestBody Product product){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Product Already Exist!"), HttpStatus.CONFLICT);
        if(!service.isProductExist(product)){
            Product newProduct = service.saveProduct(product);
            response = new ResponseEntity<>(newProduct,HttpStatus.CREATED);
        }
        return response;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findById(@PathVariable int id){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Product Not Found!"), HttpStatus.NOT_FOUND);
        Product foundProduct = service.findById(id);
        if (foundProduct != null){
            response = new ResponseEntity<>(foundProduct,HttpStatus.OK);
        }
        return response;
    }

    @GetMapping("/read/all")
    public ResponseEntity<?> findAll(){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("No Product Available!"), HttpStatus.NOT_FOUND);
        List<Product> foundProducts = service.findAllProduct();
        if (!foundProducts.isEmpty()){
            response = new ResponseEntity<>(foundProducts,HttpStatus.OK);
        }
        return response;
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable int id, @RequestBody Product product){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Product Not Found!"), HttpStatus.NOT_FOUND);
        Product product1 = service.findById(id);
        if(product1!=null){
            product.setId(id);
            service.updateProduct(product);
            response = new ResponseEntity<>(product,HttpStatus.OK);
        }
        return response;
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<?> delete(@PathVariable int id){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("ProductNot Found!"), HttpStatus.NOT_FOUND);
        Product product1 = service.findById(id);
        if(product1!=null){
            service.deleteProduct(id);
            response = new ResponseEntity<>(HttpStatus.ACCEPTED);
        }
        return response;
    }

    @DeleteMapping("/deleteAll")
    public ResponseEntity<?> deleteAll(){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Product Not exist!"), HttpStatus.NOT_FOUND);
        List<Product> product1 = service.findAllProduct();
        if(!product1.isEmpty()) {
            for (Product pro : product1) {
                service.deleteProduct(pro.getId());
            }
            response = new ResponseEntity<>(HttpStatus.ACCEPTED);
        }
        return response;
    }
}
