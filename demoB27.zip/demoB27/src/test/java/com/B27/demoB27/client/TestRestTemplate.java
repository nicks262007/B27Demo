package com.B27.demoB27.client;

import domain.Product;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

public class TestRestTemplate {

    private static final String URI = "http://localhost:8080/api";


    static void getMessage() {
        String message = new RestTemplate().getForObject(URI + "/", String.class);
        System.out.println("#####################" + message + "######################");
    }

    static void createProduct() {
        Product request = new Product("cell", "op", "china", 123);
        ResponseEntity<Object> product = (ResponseEntity<Object>) new RestTemplate().postForObject(URI + "/", request, Object.class);
        System.out.println("#####################" + product + "######################");
    }

    static void getProduct() {
        Product product = new RestTemplate().getForObject(URI + "/1", Product.class);
        System.out.println("#####################" + product + "######################");
    }

    static void readAllProducts() {
        RestTemplate result = new RestTemplate();
        List<Map<String, Object>> products = result.getForObject(URI + "/read/all", List.class);
    }

    static void updateRecord() {
        Product request = new Product("cell", "op", "india", 123);
        ResponseEntity<Object> product = (ResponseEntity<Object>) new RestTemplate().postForObject(URI + "/1", request, Object.class);
        System.out.println("#####################" + product + "######################");
    }

    static void deleteRecord() {
        new RestTemplate().delete(URI + "/delete/1");
    }

    public static void main(String[] args) {
        try {
            getMessage();
            createProduct();
            getProduct();
            readAllProducts();
            updateRecord();
            deleteRecord();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
