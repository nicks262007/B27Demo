package com.B27.demoB27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoB27ProductDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
