package controller;

import domain.Account;
import domain.Customer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import service.BankService;
import utils.CustomManageErrors;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class BankController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionController.class);

    private static final String INVALID_REQUEST =
            "Account information is invalid or transaction has been denied for your protection. Please try again.";


    @Autowired
    BankService service;


    @Value("${bank.defaultMessage}")
    String message;

    @GetMapping("/")
    public String getDefaultResponse(){
        return message;
    }

    @PostMapping("/saveAcc")
    public ResponseEntity<?> saveNewAccount(@Valid @RequestBody Account account){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Account Already Exist!"), HttpStatus.CONFLICT);
        if(!service.isProductExist(account)){
            Account newAccount = service.createAccount(account);
            response = new ResponseEntity<>(newAccount, HttpStatus.CREATED);
        }
        return response;
    }

    @GetMapping("/find/acc/{id}")
    public ResponseEntity<?> findAccount(@Valid @RequestParam int id){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Account Not Found!"), HttpStatus.NOT_FOUND);
        Optional<Account> account = service.findById(id);
        if (account != null){
            response = new ResponseEntity<>(account, HttpStatus.OK);
        }
        return response;
    }

    @GetMapping("/find/acc/all")
    public ResponseEntity<?> findAllAccount(){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("No Account Available!"), HttpStatus.NOT_FOUND);
        List<Account> accounts = service.findAllAccounts();
        if (!accounts.isEmpty()){
            response = new ResponseEntity<>(accounts,HttpStatus.OK);
        }
        return response;
    }

    @GetMapping("/find/customers/{id}")
    public ResponseEntity<?> findCustomers(@Valid @RequestParam int id){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Customer Not Found!"), HttpStatus.NOT_FOUND);
        Optional<Customer> customer  = service.findCustomerById(id);
        if (customer != null){
            response = new ResponseEntity<>(customer, HttpStatus.OK);
        }
        return response;
    }

    @GetMapping("/find/customers/all")
    public ResponseEntity<?> findAllCustomers(){
        ResponseEntity<?> response = new ResponseEntity<>(new CustomManageErrors("Customers Not Found!"), HttpStatus.NOT_FOUND);
        List<Customer> customers = service.findAllCustomers();
        if (customers != null){
            response = new ResponseEntity<>(customers, HttpStatus.OK);
        }
        return response;
    }
}
