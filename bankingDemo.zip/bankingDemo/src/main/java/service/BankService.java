package service;

import domain.Account;
import domain.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.AccountRepository;
import repository.CustomerRepository;

import java.util.List;
import java.util.Optional;

@Service
public class BankService {

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    AccountRepository accountRepository;

    public Account createAccount(Account account){
        return accountRepository.save(account);
    }

    public Optional<Account> findById(int id){
        return accountRepository.findById(id);
    }

    public Optional<Customer> findCustomerById(int id){ return customerRepository.findById(id);}

    public List<Account> findAllAccounts(){
        return accountRepository.findAll();
    }

    public List<Customer> findAllCustomers(){
        return customerRepository.findAll();
    }

    public void deleteAccount(Account account){ accountRepository.delete(account); }

    public void deleteAllAccount(){ accountRepository.deleteAll(); }

    public boolean isProductExist(Account account) { return findById(account.getId())!=null;  }
}
